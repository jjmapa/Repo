import xbmcaddon

MainBase = 'https://goo.gl/yLKTH5'
addon = xbmcaddon.Addon('plugin.video.Wow')