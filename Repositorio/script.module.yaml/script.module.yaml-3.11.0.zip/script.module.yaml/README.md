script.module.yaml
=======================

An XBMC addon that wraps up the official PyYaml classes

See the site for documentation and usage: http://pyyaml.org/
