# -*- coding: utf-8 -*-

import urllib2,urllib
import cookielib
import threading
import re
import time

BASEURL='http://sport.tvp.pl'
proxy={}
TIMEOUT = 10
BRAMKA='http://www.bramka.proxy.net.pl/index.php?q='
BRAMKA3='https://darmowe-proxy.pl'
COOKIEFILE = ''

UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'
cs=''
def getUrl(url,proxy={},timeout=TIMEOUT,cookies=True):
	global cs
	cookie=[]
	if proxy:
		urllib2.install_opener(urllib2.build_opener(urllib2.ProxyHandler(proxy)))
	elif cookies:
		cookie = cookielib.LWPCookieJar()
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie))
		urllib2.install_opener(opener)
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36')
	try:
		response = urllib2.urlopen(req,timeout=timeout)
		linkSRC = response.read()
		response.close()
	except:
		linkSRC=''
	cs = ''.join(['%s=%s;'%(c.name, c.value) for c in cookie])
	return linkSRC
	
def getChannels(url='http://sport.tvp.pl/transmisje'):
	out=[]
	content=getUrl('http://sport.tvp.pl/transmisje')
	ids = [(a.start(), a.end()) for a in re.finditer('<div class="date">', content)]
	ids.append( (-1,-1) )
	out=[]
	for i in range(len(ids[:-1])):
		subset = content[ ids[i][1]:ids[i+1][0] ]
		dzis = re.compile('<span>(DZI.*)</span>').findall(subset)
		if dzis:
			kiedy=''
		else:
			kiedy=re.compile('<span>(.*?)</span>').findall(subset)
			kiedy = kiedy[0]+' ' if kiedy else ''
		idi = [(a.start(), a.end()) for a in re.finditer('<div class="item-time live">', subset)]
		idi.append( (-1,-1) )
		for j in range(len(idi[:-1])):
			item = subset[ idi[j][1]:idi[j+1][0] ]
			href=[]
			time = re.compile('<span class="time">(.*?)</span>').findall(item)
			title= re.compile('<div class="item-title">([^<]+)</div>',re.DOTALL).findall(item)
			if not title:
				title_href = re.compile('<div class="item-title">(.*?)</div>',re.DOTALL).findall(item)
				title_href = title_href[0] if title_href else ''
				href  = re.compile('<a href="(.*?)"').findall(title_href)
				title = re.compile('>(.*?)<').findall(title_href)
			if title and time:
				t = '[COLOR lime]► [/COLOR]%s%s: [B][COLOR gold]%s[/B][/COLOR]'%(kiedy,time[0],title[0].strip()) if href else '[COLOR orangered]■ [/COLOR]%s%s: [B][COLOR gold]%s[/B][/COLOR]'%(kiedy,time[0],title[0].strip())
				code='[B][COLOR lightgreen]Live[/COLOR][/B]' if href else ''			
				href = BASEURL+href[0] if href else ''
				out.append({'title':t,'href':href,'code':code,'plot':t})
	return out
def getProxyList():
	content=getUrl('http://www.idcloak.com/proxylist/free-proxy-list-poland.html')
	speed = re.compile('<div style="width:\\d+%" title="(\\d+)%"></div>').findall(content)
	trs = re.compile('<td>(http[s]*)</td><td>(\\d+)</td><td>(.*?)</td>',re.DOTALL).findall(content)
	proxies=[{x[0]: '%s:%s'%(x[2],x[1])} for x in trs]
	return proxies
def getTVPstream(url):
	if url=='':
		return vid_link
	if url.startswith('http://sport.tvp.pl'):
		content = getUrl(url)
	else:
		content = getUrl(BASEURL+url)
	src = re.compile('data-src="(.*?)"', re.DOTALL).findall(content)
	if src:
		vid_link=BASEURL+src[0]
	return vid_link
def getChannelVideo(ex_link):
	if ex_link:
		if 'sess/tvplayer.php' in ex_link:
			url = ex_link.replace('tvpstream.tvp.pl','sport.tvp.pl')
		else:
			id = re.compile('/(\\d+)/').findall(ex_link)
			url = 'http://sport.tvp.pl/sess/tvplayer.php?copy_id=%s&object_id=%s&autoplay=true'%(id[0],id[0]) if id else ''
		stream_url = decodeUrl(url)
		proxy=False
		if not stream_url or 'material_niedostepny' in stream_url :
			stream_url = decodeUrl(url,use='pgate5')			
			if not stream_url or 'material_niedostepny' in stream_url :
				stream_url = decodeUrl(url,use='pgate3')						
			if not stream_url or 'material_niedostepny' in stream_url :
				stream_url = decodeUrl(url,use='proxy')				
			proxy=True
	else:
		stream_url=''
		proxy=False
	return stream_url,proxy
	
def getUrlProxy2(url):	
	import requests
	global COOKIEFILE
	
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': 'https://darmowe-proxy.pl/',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',
		'TE': 'Trailers',
	}
	req=requests.get(BRAMKA3,headers=headers)
	cookies=req.cookies
	data = {'u': url,'encodeURL': 'on','encodePage': 'on','allowCookies': 'on'}
	data = urllib.urlencode(data)
	vurl = BRAMKA3+'/includes/process.php?action=update'
	link=requests.post(vurl,data=data,headers=headers,cookies=cookies).content
	return link		
	
def getUrlProxy5(url):	
	import requests
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': 'https://www.sslsecureproxy.com/',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',
	}
	html=requests.get('https://www.sslsecureproxy.com/',headers=headers).content
	selip=re.findall('"(.+?)">Poland',html)[0]
	data = {
	'u': url,
	'u_default': 'https://www.google.com/',
	'urlsub': '',
	'server_name': 'pl',
	'selip': selip,
	'customip': '',
	'allowCookies': 'on',
	'autoPermalink': 'on'
	}

	response = requests.post('https://www.sslsecureproxy.com/query', headers=headers, data=data).content
	return response
	
def decodeUrl(url='http://sport.tvp.pl/sess/tvplayer.php?copy_id=35828270&object_id=35828270&autoplay=true',use=''):
	vid_link=''
	if not url: return vid_link
	if use=='pgage':
		data = getUrl(BRAMKA+urllib.quote_plus(url)+'&hl=2a5')
		vid_link = getM3u8src(data)

	elif use=='pgate5':
		data = getUrlProxy5(url)
		vid_link = getM3u8src(data)
	
	elif use=='pgate3':	
		data=getUrlProxy2(url)
		vid_link = getM3u8src(data)
		
	elif use=='proxy':
		
		proxies = getProxyList()
		listOUT = list()
		prList = [[] for x in proxies]
		for i,proxy in enumerate(proxies):
			thread = threading.Thread(name='Thread%d'%i, target = chckPrList, args=[url,proxy,prList,i])
			listOUT.append(thread)
			thread.start()
		while any([i.isAlive() for i in listOUT]) and len(vid_link)==0:
			for l in prList:
				l = prList[3]
				if isinstance(l,list):
					vid_link = l
					break
			time.sleep(0.1)
		del listOUT[:]
	else:
		data = getUrl(url)
		vid_link = getM3u8src(data)
	return vid_link
	
def getM3u8src(data):
	vid_link = re.compile('1:{src[:\\s]+[\'"](.+?)[\'"]', re.DOTALL).findall(data)
	if not vid_link:
		vid_link = re.compile("0:{src:'(.+?)'", re.DOTALL).findall(data)
	vid_link = vid_link[0] if vid_link else ''
	return vid_link
	
def chckPrList(ex_link ,proxy, prList, index):
	data = getUrl(ex_link,proxy,timeout=10)
	linkSRC = m3u8Quality(getM3u8src(data))
	prList[index]= linkSRC if not 'material_niedostepny' in linkSRC else ''
	
def m3u8Quality(url):
	out=url
	if url and url.endswith('.m3u8'):
		srcm3u8 = re.search('/(\\w+)\\.m3u8',url)
		srcm3u8 = srcm3u8.group(1) if srcm3u8 else 'manifest'
		content = getUrl(url)
		matches=re.compile('RESOLUTION=(.*?)\r\n(QualityLevels\\(.*\\)/manifest\\(format=m3u8-aapl\\))').findall(content)
		if matches:
			out=[{'title':'auto','url':url}]
			for title, part in matches:
				one={'title':title,'url':url.replace(srcm3u8,part)}
				out.append(one)
	return out
